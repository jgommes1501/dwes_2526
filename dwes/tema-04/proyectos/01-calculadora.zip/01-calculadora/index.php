<?php

/*
    Proyecto 01: 
*/


//Incluir la clase calculadora
require_once 'class/calculadora.class.php';


include 'views/index.view.php'
?>