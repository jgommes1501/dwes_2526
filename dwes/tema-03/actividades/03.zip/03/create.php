<?php

/*
    Actividad 3.3
    Archivo: create.php
    Descripción: Añadir funcionalidad - Añadir Libro.
    Autor: Jaime Gómez Mesa
    Fecha: 22/10/2025
*/

include 'models/create.model.php';

include 'views/nuevo.view.php';

include 'libs/functions.php';

?>