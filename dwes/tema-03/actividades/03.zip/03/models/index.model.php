<?php

/*
    Actividad 3.3
    Archivo: index.model.php
    Descripción: Añadir funcionalidad - Añadir Libro
    Autor: Jaime Gómez Mesa
    Fecha: 20/10/2025
*/

// Cargar el array de libros
$libros = get_tabla_libros();
?>