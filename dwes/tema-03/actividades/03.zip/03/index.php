<?php

/*
    Actividad 3.3
    Archivo: index.php
    Descripción: Añadir funcionalidad - Añadir Libro.
    Autor: Jaime Gómez Mesa
    Fecha: 22/10/2025
*/

include 'libs/functions.php';

include 'models/index.model.php';

include 'views/index.view.php';

?>