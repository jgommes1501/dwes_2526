<?php

include 'libs/functions.php';
include 'models/update.model.php';
include 'views/index.view.php';