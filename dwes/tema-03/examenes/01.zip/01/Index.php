<?php

include 'libs/functions.php';

include 'models/index.model.php';

include 'views/index.view.php';

