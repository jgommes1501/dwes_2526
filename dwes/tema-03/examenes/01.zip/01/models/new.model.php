<?php

$peliculas = get_peliculas();