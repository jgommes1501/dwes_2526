<?php

// Lamar a la array de películas
$peliculas = get_peliculas();

