<?php
/**
 * Modelo para la página principal
 */
$peliculas = get_peliculas();