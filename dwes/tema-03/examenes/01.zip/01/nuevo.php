<?php

include 'libs/functions.php';

include 'models/new.model.php';

include 'views/new.view.php';

