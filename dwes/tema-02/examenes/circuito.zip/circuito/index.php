<?php

require_once("views/view.index.php");
?>