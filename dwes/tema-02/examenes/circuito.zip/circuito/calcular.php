<?php

require_once("models/model.circuito.php");
require_once("views/view.resultados.php");

?>